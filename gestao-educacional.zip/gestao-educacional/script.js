// script.js - Arquivo Principal do Sistema
// Sistema de Gestão Educacional Municipal - VERSÃO 8.1 CORRIGIDA
// CORREÇÃO: Removida recursão infinita

// ==================== VERIFICAÇÃO INICIAL ====================
if (typeof SISTEMA_EDUCACIONAL === 'undefined') {
    
    // ==================== CONSTANTES GLOBAIS ====================
    const CONFIG = {
        nome: 'Sistema de Gestão Educacional Municipal',
        versao: '8.1.0',
        debug: true,
        storageKey: 'sme_sessao',
        sessionTimeout: 24 * 60 * 60 * 1000
    };

    // ==================== ESTADO GLOBAL ====================
    const Estado = {
        autenticado: false,
        usuario: null,
        perfil: null,
        view: 'login',
        sidebar: false,
        modulo: 'dashboard',
        secao: 'home',
        idioma: 'pt-BR',
        tema: 'claro'
    };

    // ==================== CONTROLE ANTI-RECURSÃO ====================
    const __recursionControl = {
        emExecucao: false,
        ultimaChamada: null
    };

    // ==================== INICIALIZAÇÃO ====================
    document.addEventListener('DOMContentLoaded', function() {
        console.log(`${CONFIG.nome} v${CONFIG.versao} - Inicializando...`);
        
        if (typeof MOCK_DATA === 'undefined') {
            console.error('ERRO: MOCK_DATA não foi carregado!');
            mostrarMensagem('Erro ao carregar dados do sistema.', 'error');
            return;
        }
        
        carregarEstilos();
        verificarSessao();
        configurarEventos();
        configurarModal();
        
        // Não inicializar módulos automaticamente para evitar loops
        if (Estado.autenticado) {
            setTimeout(inicializarModulosEssenciais, 500);
        }
        
        atualizarInterface();
        console.log('✅ Sistema inicializado com sucesso!');
    });

    // ==================== INICIALIZAÇÃO DE MÓDULOS (SIMPLIFICADA) ====================
    function inicializarModulosEssenciais() {
        // Inicializar apenas módulos essenciais que não causam recursão
        const modulos = [
            'MODULO_NOTIFICACOES',
            'MODULO_GRAFICOS',
            'MODULO_TEMAS',
            'MODULO_ACESSIBILIDADE'
        ];
        
        modulos.forEach(nome => {
            if (typeof window[nome] !== 'undefined' && window[nome].init) {
                try {
                    window[nome].init();
                } catch (e) {
                    console.warn(`⚠️ Erro ao iniciar ${nome}:`, e);
                }
            }
        });
    }

    // ==================== FUNÇÕES DE AUTENTICAÇÃO ====================
    function verificarSessao() {
        try {
            const sessao = localStorage.getItem(CONFIG.storageKey);
            if (sessao) {
                const dados = JSON.parse(sessao);
                const agora = Date.now();
                
                if (dados.expira && agora < dados.expira) {
                    Estado.autenticado = true;
                    Estado.usuario = dados.usuario;
                    Estado.perfil = dados.perfil;
                    Estado.view = 'dashboard';
                    
                    console.log(`Sessão recuperada: ${dados.usuario.nome} (${dados.perfil})`);
                } else {
                    localStorage.removeItem(CONFIG.storageKey);
                }
            }
        } catch (erro) {
            console.error('Erro ao verificar sessão:', erro);
        }
    }

    function fazerLogin(email, senha, perfil) {
        if (!email || !senha || !perfil) {
            mostrarMensagem('Preencha todos os campos!', 'error');
            return;
        }

        mostrarLoading('Autenticando...');

        setTimeout(() => {
            try {
                const usuario = MOCK_DATA.usuarios.find(u => 
                    u.email.toLowerCase() === email.toLowerCase() && 
                    u.senha === senha && 
                    u.perfil === perfil
                );

                if (usuario) {
                    completarLogin(usuario);
                } else {
                    esconderLoading();
                    mostrarMensagem('Email, senha ou perfil incorretos!', 'error');
                    document.getElementById('password').value = '';
                }
            } catch (erro) {
                esconderLoading();
                mostrarMensagem('Erro ao processar login', 'error');
                console.error(erro);
            }
        }, 1000);
    }

    function completarLogin(usuario) {
        Estado.autenticado = true;
        Estado.usuario = usuario;
        Estado.perfil = usuario.perfil;
        Estado.view = 'dashboard';

        const sessao = {
            usuario: {
                id: usuario.id,
                nome: usuario.nome,
                email: usuario.email,
                perfil: usuario.perfil,
                escolaId: usuario.escolaId
            },
            perfil: usuario.perfil,
            expira: Date.now() + CONFIG.sessionTimeout
        };
        localStorage.setItem(CONFIG.storageKey, JSON.stringify(sessao));

        esconderLoading();
        mostrarMensagem(`Bem-vindo(a), ${usuario.nome}!`, 'success');
        
        atualizarInterface();
        navegarPara('dashboard', 'home');
    }

    function fazerLogout() {
        mostrarLoading('Saindo...');

        setTimeout(() => {
            Estado.autenticado = false;
            Estado.usuario = null;
            Estado.perfil = null;
            Estado.view = 'login';

            localStorage.removeItem(CONFIG.storageKey);

            document.getElementById('username').value = '';
            document.getElementById('password').value = '';
            document.getElementById('login-type').value = '';

            esconderLoading();
            mostrarMensagem('Logout realizado com sucesso!', 'info');
            
            atualizarInterface();
        }, 500);
    }

    // ==================== FUNÇÕES DE INTERFACE ====================
    function atualizarInterface() {
        const telaLogin = document.getElementById('login-screen');
        const telaDashboard = document.getElementById('dashboard-screen');

        if (Estado.view === 'login') {
            telaLogin?.classList.add('active');
            telaDashboard?.classList.remove('active');
        } else {
            telaLogin?.classList.remove('active');
            telaDashboard?.classList.add('active');
            
            document.getElementById('current-user').textContent = Estado.usuario?.nome || 'Usuário';
            document.getElementById('current-role').textContent = getNomePerfil(Estado.perfil);
            
            carregarMenu();
        }
    }

    function getNomePerfil(perfil) {
        const nomes = {
            'secretaria': 'Secretaria da Educação',
            'diretor': 'Diretor de Escola',
            'professor': 'Professor',
            'aluno': 'Aluno'
        };
        return nomes[perfil] || perfil;
    }

    function carregarMenu() {
        const menu = document.getElementById('sidebar-menu');
        if (!menu) return;

        menu.innerHTML = '';

        const itens = getItensMenu();
        
        itens.forEach(item => {
            const li = document.createElement('li');
            li.className = 'menu-item';
            
            const a = document.createElement('a');
            a.href = '#';
            a.className = 'menu-link';
            a.setAttribute('data-modulo', item.modulo);
            a.setAttribute('data-secao', item.secao);
            a.innerHTML = `<i class="${item.icone}"></i> <span>${item.titulo}</span>`;
            
            a.addEventListener('click', (e) => {
                e.preventDefault();
                navegarPara(item.modulo, item.secao);
            });
            
            li.appendChild(a);
            menu.appendChild(li);
        });

        document.querySelectorAll('.menu-link').forEach(link => {
            if (link.dataset.modulo === Estado.modulo && link.dataset.secao === Estado.secao) {
                link.classList.add('active');
            }
        });
    }

    function getItensMenu() {
        const base = [
            { modulo: 'dashboard', secao: 'home', icone: 'fas fa-home', titulo: 'Dashboard' }
        ];

        const menus = {
            'secretaria': [
                ...base,
                { modulo: 'escolas', secao: 'listar', icone: 'fas fa-school', titulo: 'Escolas' },
                { modulo: 'professores', secao: 'listar', icone: 'fas fa-chalkboard-teacher', titulo: 'Professores' },
                { modulo: 'alunos', secao: 'listar', icone: 'fas fa-graduation-cap', titulo: 'Alunos' },
                { modulo: 'turmas', secao: 'listar', icone: 'fas fa-users', titulo: 'Turmas' },
                { modulo: 'perfil', secao: 'ver', icone: 'fas fa-user', titulo: 'Meu Perfil' }
            ],
            'diretor': [
                ...base,
                { modulo: 'escola', secao: 'ver', icone: 'fas fa-school', titulo: 'Minha Escola' },
                { modulo: 'professores', secao: 'listar', icone: 'fas fa-chalkboard-teacher', titulo: 'Professores' },
                { modulo: 'alunos', secao: 'listar', icone: 'fas fa-graduation-cap', titulo: 'Alunos' },
                { modulo: 'turmas', secao: 'listar', icone: 'fas fa-users', titulo: 'Turmas' },
                { modulo: 'perfil', secao: 'ver', icone: 'fas fa-user', titulo: 'Meu Perfil' }
            ],
            'professor': [
                ...base,
                { modulo: 'turmas', secao: 'minhas', icone: 'fas fa-users', titulo: 'Minhas Turmas' },
                { modulo: 'notas', secao: 'lancar', icone: 'fas fa-edit', titulo: 'Lançar Notas' },
                { modulo: 'frequencia', secao: 'registrar', icone: 'fas fa-clipboard-check', titulo: 'Frequência' },
                { modulo: 'alunos', secao: 'meus', icone: 'fas fa-graduation-cap', titulo: 'Meus Alunos' },
                { modulo: 'perfil', secao: 'ver', icone: 'fas fa-user', titulo: 'Meu Perfil' }
            ],
            'aluno': [
                ...base,
                { modulo: 'boletim', secao: 'ver', icone: 'fas fa-file-alt', titulo: 'Meu Boletim' },
                { modulo: 'notas', secao: 'minhas', icone: 'fas fa-chart-line', titulo: 'Minhas Notas' },
                { modulo: 'faltas', secao: 'ver', icone: 'fas fa-calendar-times', titulo: 'Minhas Faltas' },
                { modulo: 'horario', secao: 'ver', icone: 'fas fa-clock', titulo: 'Meu Horário' },
                { modulo: 'perfil', secao: 'ver', icone: 'fas fa-user', titulo: 'Meu Perfil' }
            ]
        };

        return menus[Estado.perfil] || base;
    }

    function navegarPara(modulo, secao, parametro = null) {
        // CONTROLE ANTI-RECURSÃO
        if (__recursionControl.emExecucao) {
            console.warn('⚠️ Prevenida chamada recursiva em navegarPara');
            return;
        }

        __recursionControl.emExecucao = true;
        __recursionControl.ultimaChamada = { modulo, secao };

        try {
            Estado.modulo = modulo;
            Estado.secao = secao;

            const titulo = document.getElementById('dashboard-title');
            const itemAtual = getItensMenu().find(i => i.modulo === modulo && i.secao === secao);
            if (titulo && itemAtual) {
                titulo.textContent = itemAtual.titulo;
            }

            carregarConteudo(modulo, secao, parametro);

            document.querySelectorAll('.menu-link').forEach(link => {
                link.classList.remove('active');
                if (link.dataset.modulo === modulo && link.dataset.secao === secao) {
                    link.classList.add('active');
                }
            });
        } finally {
            __recursionControl.emExecucao = false;
        }
    }

    function carregarConteudo(modulo, secao, parametro = null) {
    const area = document.getElementById('content-area');
    if (!area) return;

    // CONTROLE ANTI-RECURSÃO
    if (window.__carregandoModulo === modulo) {
        console.warn(`⚠️ Prevenida chamada recursiva para ${modulo}`);
        return;
    }
    window.__carregandoModulo = modulo;

    area.innerHTML = `
        <div class="loading-content">
            <div class="loading-spinner"></div>
            <div class="loading-text">Carregando...</div>
        </div>
    `;

    setTimeout(() => {
        let html = '';

        try {
            // CASOS ESPECIAIS (não usam loader)
            if (modulo === 'dashboard') {
                html = renderizarDashboard();
            }
            else if (modulo === 'perfil') {
                html = renderizarPerfil();
            }
            else {
                // USAR O LOADER PARA TODOS OS OUTROS MÓDULOS
                if (typeof MODULO_LOADER !== 'undefined') {
                    // Mapeamento de módulos
                    const mapa = {
                        // Secretaria
                        'escolas': { mod: 'SECRETARIA', fn: 'renderizarEscolas' },
                        'professores': { mod: 'SECRETARIA', fn: 'renderizarProfessores' },
                        'alunos': Estado.perfil === 'professor' 
                            ? { mod: 'PROFESSOR', fn: 'renderizarMeusAlunos' }
                            : { mod: 'SECRETARIA', fn: 'renderizarAlunos' },
                        'turmas': Estado.perfil === 'professor'
                            ? { mod: 'PROFESSOR', fn: 'renderizarMinhasTurmas' }
                            : { mod: 'SECRETARIA', fn: 'renderizarTurmas' },
                        
                        // Diretor
                        'escola': { mod: 'DIRETOR', fn: 'renderizarMinhaEscola' },
                        'ocorrencias': { mod: 'DIRETOR', fn: 'renderizarOcorrencias' },
                        'reunioes': { mod: 'REUNIOES', fn: 'renderizarReunioes' },
                        'projetos': { mod: 'PROJETOS', fn: 'renderizarProjetos' },
                        
                        // Professor
                        'notas': Estado.perfil === 'professor'
                            ? { mod: 'PROFESSOR', fn: 'renderizarLancarNotas' }
                            : Estado.perfil === 'aluno'
                            ? { mod: 'ALUNO', fn: 'renderizarMinhasNotas' }
                            : null,
                        'frequencia': Estado.perfil === 'professor'
                            ? { mod: 'PROFESSOR', fn: 'renderizarRegistrarFrequencia' }
                            : null,
                        'atividades': Estado.perfil === 'professor'
                            ? { mod: 'ATIVIDADES', fn: 'renderizarAtividades' }
                            : Estado.perfil === 'aluno'
                            ? { mod: 'ALUNO', fn: 'renderizarAtividadesPendentes' }
                            : null,
                        
                        // Aluno
                        'boletim': { mod: 'ALUNO', fn: 'renderizarBoletim' },
                        'faltas': { mod: 'ALUNO', fn: 'renderizarMinhasFaltas' },
                        'horario': Estado.perfil === 'professor'
                            ? { mod: 'PROFESSOR', fn: 'renderizarHorario' }
                            : { mod: 'ALUNO', fn: 'renderizarMeuHorario' },
                        
                        // Outros
                        'biblioteca': { mod: 'BIBLIOTECA', fn: 'renderizarLivros' },
                        'merenda': { mod: 'MERENDA', fn: 'renderizarCardapio' },
                        'transporte': Estado.perfil === 'aluno'
                            ? { mod: 'TRANSPORTE', fn: 'renderizarMeuTransporte' }
                            : { mod: 'TRANSPORTE', fn: 'renderizarRotas' },
                        'saude': { mod: 'SAUDE', fn: 'renderizarSaudeAlunos' },
                        'bolsas': { mod: 'BOLSAS', fn: 'renderizarBolsas' },
                        'estagio': { mod: 'ESTAGIO', fn: 'renderizarMeuEstagio' },
                        'monitoria': { mod: 'MONITORIA', fn: 'renderizarMonitorias' },
                        'competicoes': { mod: 'COMPETICOES', fn: 'renderizarCompeticoes' },
                        'horas': { mod: 'HORAS', fn: 'renderizarHorasComplementares' },
                        'pesquisas': { mod: 'PESQUISAS', fn: 'renderizarPesquisas' },
                        'documentos': { mod: 'DOCUMENTOS', fn: 'renderizarDocumentos' },
                        'uniforme': { mod: 'UNIFORME', fn: 'renderizarUniforme' },
                        'cursos': { mod: 'CURSOS', fn: 'renderizarCursos' },
                        'feedback': { mod: 'FEEDBACK', fn: 'renderizarFeedbacks' },
                        'relatorios': { mod: 'RELATORIOS', fn: 'renderizarRelatorios' },
                        
                        // Fase 2
                        'graficos': { mod: 'GRAFICOS', fn: 'criarGraficoDesempenhoGeral' },
                        'notificacoes': { mod: 'NOTIFICACOES', fn: 'abrirCentralNotificacoes' },
                        'exportacao': { mod: 'EXPORTACAO', fn: 'criarModalExportacao' },
                        'backup': { mod: 'BACKUP', fn: 'abrirPainelBackup' },
                        
                        // Fase 3
                        'auditoria': { mod: 'AUDITORIA', fn: 'abrirPainelAuditoria' },
                        '2fa': { mod: 'DOISFA', fn: 'mostrarModalConfiguracao' },
                        'i18n': { mod: 'I18N', fn: 'abrirConfiguracoes' },
                        
                        // Fase 4 - IA
                        'ia-previsao': { mod: 'IA_PREVISAO', fn: 'mostrarPainelIA' },
                        'ia-recomendacao': { mod: 'IA_RECOMENDACAO', fn: 'mostrarPainelRecomendacoes' },
                        'ia-evasao': { mod: 'IA_EVASAO', fn: 'mostrarPainelEvasao' },
                        'chatbot': { mod: 'CHATBOT', fn: 'abrirChatbot' }
                    };

                    const mapeado = mapa[modulo];
                    
                    if (mapeado) {
                        if (mapeado.fn.includes('Modal') || mapeado.fn.includes('Abrir') || mapeado.fn.includes('mostrar')) {
                            // Funções que abrem modal - executar e retornar vazio
                            MODULO_LOADER.executarFuncao(mapeado.mod, mapeado.fn, secao, parametro);
                            html = ''; // Modal já foi aberto
                        } else {
                            // Funções que retornam HTML
                            html = MODULO_LOADER.executarFuncao(mapeado.mod, mapeado.fn, secao, parametro);
                        }
                    } else {
                        html = gerarMensagemNaoImplementado(modulo);
                    }
                } else {
                    html = gerarMensagemNaoImplementado(modulo);
                }
            }

            if (html) {
                area.innerHTML = html;
            }

        } catch (erro) {
            console.error('Erro ao carregar conteúdo:', erro);
            area.innerHTML = gerarMensagemErro(erro.message);
        } finally {
            window.__carregandoModulo = null;
        }
    }, 500);
}

// Funções auxiliares
function gerarMensagemNaoImplementado(modulo) {
    return `
        <div style="text-align: center; padding: 50px; background: white; border-radius: 10px; margin: 20px;">
            <i class="fas fa-code" style="font-size: 64px; color: #3498db; margin-bottom: 20px;"></i>
            <h2 style="color: #2c3e50; margin-bottom: 15px;">Módulo em Desenvolvimento</h2>
            <p style="color: #7f8c8d; margin-bottom: 30px;">O módulo <strong>${modulo}</strong> está sendo implementado.</p>
            <button class="btn btn-primary" onclick="navegarPara('dashboard', 'home')">
                <i class="fas fa-home"></i> Voltar ao Dashboard
            </button>
        </div>
    `;
}

function gerarMensagemErro(erro) {
    return `
        <div style="text-align: center; padding: 50px; background: white; border-radius: 10px; margin: 20px;">
            <i class="fas fa-exclamation-triangle" style="font-size: 64px; color: #e74c3c; margin-bottom: 20px;"></i>
            <h2 style="color: #2c3e50; margin-bottom: 15px;">Erro ao Carregar</h2>
            <p style="color: #7f8c8d; margin-bottom: 20px;">${erro}</p>
            <button class="btn btn-primary" onclick="window.location.reload()">
                <i class="fas fa-sync-alt"></i> Recarregar
            </button>
        </div>
    `;
}
    function gerarMensagemNaoImplementado(modulo) {
        return `
            <div class="modulo-nao-implementado" style="text-align: center; padding: 50px; background: white; border-radius: 10px; margin: 20px;">
                <i class="fas fa-code" style="font-size: 64px; color: #3498db; margin-bottom: 20px;"></i>
                <h2 style="color: #2c3e50; margin-bottom: 15px;">Módulo em Desenvolvimento</h2>
                <p style="color: #7f8c8d; margin-bottom: 30px;">O módulo <strong>${modulo}</strong> está sendo implementado e estará disponível em breve.</p>
                <p style="color: #95a5a6; font-size: 0.9rem;">Esta é uma versão de demonstração para investidores.</p>
                <button class="btn btn-primary" onclick="navegarPara('dashboard', 'home')" style="margin-top: 20px;">
                    <i class="fas fa-home"></i> Voltar ao Dashboard
                </button>
            </div>
        `;
    }

    function gerarMensagemErro(erro) {
        return `
            <div class="erro-modulo" style="text-align: center; padding: 50px; background: white; border-radius: 10px; margin: 20px;">
                <i class="fas fa-exclamation-triangle" style="font-size: 64px; color: #e74c3c; margin-bottom: 20px;"></i>
                <h2 style="color: #2c3e50; margin-bottom: 15px;">Erro ao Carregar</h2>
                <p style="color: #7f8c8d; margin-bottom: 10px;">Ocorreu um erro ao carregar esta funcionalidade.</p>
                <p style="color: #95a5a6; font-size: 0.9rem; margin-bottom: 20px;">${erro}</p>
                <button class="btn btn-primary" onclick="window.location.reload()">
                    <i class="fas fa-sync-alt"></i> Recarregar Página
                </button>
            </div>
        `;
    }

    // ==================== RENDERIZADORES ====================
    function renderizarDashboard() {
        switch(Estado.perfil) {
            case 'secretaria':
                return renderizarDashboardSecretaria();
            case 'diretor':
                return renderizarDashboardDiretor();
            case 'professor':
                return renderizarDashboardProfessor();
            case 'aluno':
                return renderizarDashboardAluno();
            default:
                return renderizarDashboardGenerico();
        }
    }

    function renderizarDashboardSecretaria() {
        const totalEscolas = MOCK_DATA.escolas?.length || 0;
        const totalProfessores = MOCK_DATA.professores?.length || 0;
        const totalAlunos = MOCK_DATA.alunos?.length || 0;
        const totalTurmas = MOCK_DATA.turmas?.length || 0;

        return `
            <div class="dashboard-content">
                <div class="welcome-header">
                    <h1>Painel da Secretaria</h1>
                    <p class="welcome-subtitle">Bem-vindo(a), ${Estado.usuario?.nome || 'Usuário'}</p>
                </div>
                
                <div class="dashboard-stats">
                    <div class="stat-card" onclick="navegarPara('escolas', 'listar')">
                        <div class="stat-icon bg-primary">
                            <i class="fas fa-school"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Escolas</h3>
                            <p class="stat-number">${totalEscolas}</p>
                            <p class="stat-change">${MOCK_DATA.escolas?.filter(e => e.status === 'ativa').length || 0} ativas</p>
                        </div>
                    </div>
                    
                    <div class="stat-card" onclick="navegarPara('professores', 'listar')">
                        <div class="stat-icon bg-success">
                            <i class="fas fa-chalkboard-teacher"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Professores</h3>
                            <p class="stat-number">${totalProfessores}</p>
                            <p class="stat-change">${MOCK_DATA.professores?.filter(p => p.status === 'ativo').length || 0} ativos</p>
                        </div>
                    </div>
                    
                    <div class="stat-card" onclick="navegarPara('alunos', 'listar')">
                        <div class="stat-icon bg-warning">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Alunos</h3>
                            <p class="stat-number">${totalAlunos}</p>
                            <p class="stat-change">${MOCK_DATA.alunos?.filter(a => a.status === 'ativo').length || 0} ativos</p>
                        </div>
                    </div>
                    
                    <div class="stat-card" onclick="navegarPara('turmas', 'listar')">
                        <div class="stat-icon bg-info">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Turmas</h3>
                            <p class="stat-number">${totalTurmas}</p>
                            <p class="stat-change">${Math.round(totalAlunos/(totalTurmas || 1))} alunos/turma</p>
                        </div>
                    </div>
                </div>
                
                <div class="dashboard-sections">
                    <div class="quick-actions">
                        <h2><i class="fas fa-bolt"></i> Ações Rápidas</h2>
                        <div class="action-buttons">
                            <button class="action-btn" onclick="navegarPara('escolas', 'listar')">
                                <i class="fas fa-school"></i> Gerenciar Escolas
                            </button>
                            <button class="action-btn" onclick="navegarPara('professores', 'listar')">
                                <i class="fas fa-chalkboard-teacher"></i> Gerenciar Professores
                            </button>
                            <button class="action-btn" onclick="navegarPara('alunos', 'listar')">
                                <i class="fas fa-graduation-cap"></i> Gerenciar Alunos
                            </button>
                            <button class="action-btn" onclick="navegarPara('relatorios', 'listar')">
                                <i class="fas fa-chart-bar"></i> Relatórios
                            </button>
                        </div>
                    </div>
                    
                    <div class="recent-activity">
                        <h2><i class="fas fa-chart-line"></i> Visão Geral</h2>
                        <div class="stats-mini">
                            <div class="stat-mini-item">
                                <span class="stat-mini-label">Rede Municipal</span>
                                <span class="stat-mini-value">${totalEscolas} escolas</span>
                            </div>
                            <div class="stat-mini-item">
                                <span class="stat-mini-label">Corpo Docente</span>
                                <span class="stat-mini-value">${totalProfessores} professores</span>
                            </div>
                            <div class="stat-mini-item">
                                <span class="stat-mini-label">Corpo Discente</span>
                                <span class="stat-mini-value">${totalAlunos} alunos</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    function renderizarDashboardDiretor() {
        const escola = MOCK_DATA.escolas?.find(e => e.id === Estado.usuario?.escolaId) || MOCK_DATA.escolas?.[0] || { nome: 'Escola não encontrada' };
        const professores = MOCK_DATA.professores?.filter(p => p.escolaId === escola.id) || [];
        const alunos = MOCK_DATA.alunos?.filter(a => a.escolaId === escola.id) || [];
        const turmas = MOCK_DATA.turmas?.filter(t => t.escolaId === escola.id) || [];

        return `
            <div class="dashboard-content">
                <div class="welcome-header">
                    <h1>Painel do Diretor</h1>
                    <p class="welcome-subtitle">${escola.nome}</p>
                </div>
                
                <div class="dashboard-stats">
                    <div class="stat-card" onclick="navegarPara('professores', 'listar')">
                        <div class="stat-icon bg-primary">
                            <i class="fas fa-chalkboard-teacher"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Professores</h3>
                            <p class="stat-number">${professores.length}</p>
                            <p class="stat-change">${professores.filter(p => p.status === 'ativo').length} ativos</p>
                        </div>
                    </div>
                    
                    <div class="stat-card" onclick="navegarPara('alunos', 'listar')">
                        <div class="stat-icon bg-success">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Alunos</h3>
                            <p class="stat-number">${alunos.length}</p>
                            <p class="stat-change">${alunos.filter(a => a.status === 'ativo').length} ativos</p>
                        </div>
                    </div>
                    
                    <div class="stat-card" onclick="navegarPara('turmas', 'listar')">
                        <div class="stat-icon bg-warning">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Turmas</h3>
                            <p class="stat-number">${turmas.length}</p>
                            <p class="stat-change">${turmas.length} ativas</p>
                        </div>
                    </div>
                </div>
                
                <div class="dashboard-sections">
                    <div class="quick-actions">
                        <h2><i class="fas fa-bolt"></i> Ações Rápidas</h2>
                        <div class="action-buttons">
                            <button class="action-btn" onclick="navegarPara('professores', 'listar')">
                                <i class="fas fa-chalkboard-teacher"></i> Ver Professores
                            </button>
                            <button class="action-btn" onclick="navegarPara('alunos', 'listar')">
                                <i class="fas fa-graduation-cap"></i> Ver Alunos
                            </button>
                            <button class="action-btn" onclick="navegarPara('turmas', 'listar')">
                                <i class="fas fa-users"></i> Ver Turmas
                            </button>
                        </div>
                    </div>
                    
                    <div class="recent-activity">
                        <h2><i class="fas fa-calendar-alt"></i> Próximos Eventos</h2>
                        <div class="event-list">
                            <p>Carregando eventos...</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    function renderizarDashboardProfessor() {
        const professor = MOCK_DATA.professores?.find(p => p.email === Estado.usuario?.email);
        if (!professor) return '<div class="error-message">Professor não encontrado</div>';

        const turmas = MOCK_DATA.turmas?.filter(t => t.professorId === professor.id) || [];
        const totalAlunos = turmas.reduce((acc, t) => acc + (t.totalAlunos || 0), 0);

        return `
            <div class="dashboard-content">
                <div class="welcome-header">
                    <h1>Painel do Professor</h1>
                    <p class="welcome-subtitle">${professor.disciplina} - ${totalAlunos} alunos</p>
                </div>
                
                <div class="dashboard-stats">
                    <div class="stat-card" onclick="navegarPara('turmas', 'minhas')">
                        <div class="stat-icon bg-primary">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Minhas Turmas</h3>
                            <p class="stat-number">${turmas.length}</p>
                            <p class="stat-change">${totalAlunos} alunos</p>
                        </div>
                    </div>
                    
                    <div class="stat-card" onclick="navegarPara('notas', 'lancar')">
                        <div class="stat-icon bg-warning">
                            <i class="fas fa-edit"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Notas a Lançar</h3>
                            <p class="stat-number">12</p>
                            <p class="stat-change">a lançar</p>
                        </div>
                    </div>
                </div>
                
                <div class="dashboard-sections">
                    <div class="quick-actions">
                        <h2><i class="fas fa-bolt"></i> Ações Rápidas</h2>
                        <div class="action-buttons">
                            <button class="action-btn" onclick="navegarPara('notas', 'lancar')">
                                <i class="fas fa-edit"></i> Lançar Notas
                            </button>
                            <button class="action-btn" onclick="navegarPara('frequencia', 'registrar')">
                                <i class="fas fa-clipboard-check"></i> Registrar Frequência
                            </button>
                        </div>
                    </div>
                    
                    <div class="recent-activity">
                        <h2><i class="fas fa-clock"></i> Próximas Aulas</h2>
                        <div class="schedule-list">
                            <p>Carregando horários...</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    function renderizarDashboardAluno() {
        const aluno = MOCK_DATA.alunos?.find(a => a.email === Estado.usuario?.email);
        if (!aluno) return '<div class="error-message">Aluno não encontrado</div>';

        return `
            <div class="dashboard-content">
                <div class="welcome-header">
                    <h1>Olá, ${aluno.nome}!</h1>
                    <p class="welcome-subtitle">Turma ${aluno.turma} • Matrícula ${aluno.matricula}</p>
                </div>
                
                <div class="dashboard-stats">
                    <div class="stat-card" onclick="navegarPara('boletim', 'ver')">
                        <div class="stat-icon bg-primary">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Média Geral</h3>
                            <p class="stat-number">${aluno.mediaGeral}</p>
                        </div>
                    </div>
                    
                    <div class="stat-card" onclick="navegarPara('faltas', 'ver')">
                        <div class="stat-icon bg-success">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Frequência</h3>
                            <p class="stat-number">${Math.round((1 - (aluno.faltas || 0)/80)*100)}%</p>
                        </div>
                    </div>
                    
                    <div class="stat-card" onclick="navegarPara('atividades', 'pendentes')">
                        <div class="stat-icon bg-warning">
                            <i class="fas fa-tasks"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Atividades</h3>
                            <p class="stat-number">3</p>
                        </div>
                    </div>
                </div>
                
                <div class="dashboard-sections">
                    <div class="quick-actions">
                        <h2><i class="fas fa-bolt"></i> Ações Rápidas</h2>
                        <div class="action-buttons">
                            <button class="action-btn" onclick="navegarPara('boletim', 'ver')">
                                <i class="fas fa-file-alt"></i> Ver Boletim
                            </button>
                            <button class="action-btn" onclick="navegarPara('horario', 'ver')">
                                <i class="fas fa-clock"></i> Ver Horário
                            </button>
                        </div>
                    </div>
                    
                    <div class="recent-activity">
                        <h2><i class="fas fa-clock"></i> Próxima Aula</h2>
                        <div class="schedule-list">
                            <p>Carregando horários...</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    function renderizarDashboardGenerico() {
        return `
            <div class="dashboard-content">
                <div class="welcome-header">
                    <h1>Bem-vindo(a), ${Estado.usuario?.nome || 'Usuário'}!</h1>
                    <p class="welcome-subtitle">${getNomePerfil(Estado.perfil)}</p>
                </div>
                
                <div class="content-placeholder">
                    <h2>Dashboard em desenvolvimento</h2>
                    <p>Em breve você terá estatísticas personalizadas.</p>
                </div>
            </div>
        `;
    }

    function renderizarPerfil() {
        const user = Estado.usuario;
        if (!user) return '<div class="error-message">Usuário não encontrado</div>';

        return `
            <div class="profile-content">
                <div class="content-header">
                    <h1><i class="fas fa-user"></i> Meu Perfil</h1>
                </div>
                
                <div class="profile-card">
                    <div class="profile-avatar">
                        <img src="${user.avatar || 'https://i.pravatar.cc/150'}" alt="${user.nome}">
                    </div>
                    
                    <div class="profile-details">
                        <div class="detail-row">
                            <label>Nome Completo:</label>
                            <span>${user.nome}</span>
                        </div>
                        <div class="detail-row">
                            <label>E-mail:</label>
                            <span>${user.email}</span>
                        </div>
                        <div class="detail-row">
                            <label>Telefone:</label>
                            <span>${user.telefone || 'Não informado'}</span>
                        </div>
                        <div class="detail-row">
                            <label>Perfil:</label>
                            <span class="role-badge">${getNomePerfil(user.perfil)}</span>
                        </div>
                        <div class="detail-row">
                            <label>Último Acesso:</label>
                            <span>${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</span>
                        </div>
                    </div>
                    
                    <div class="profile-actions">
                        <button class="btn btn-primary" onclick="abrirModal('Editar Perfil', getFormEditarPerfil())">
                            <i class="fas fa-edit"></i> Editar Perfil
                        </button>
                        <button class="btn btn-secondary" onclick="abrirModal('Alterar Senha', getFormAlterarSenha())">
                            <i class="fas fa-key"></i> Alterar Senha
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    // ==================== FUNÇÕES AUXILIARES ====================
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('main-content');
        const footer = document.querySelector('.footer');

        Estado.sidebar = !Estado.sidebar;
        
        if (sidebar) sidebar.classList.toggle('collapsed');
        if (mainContent) mainContent.classList.toggle('expanded');
        if (footer) footer.classList.toggle('expanded');
    }

    function mostrarMensagem(texto, tipo = 'info') {
        const msg = document.createElement('div');
        msg.className = `global-message message-${tipo}`;
        msg.innerHTML = `
            <div class="message-content">
                <i class="fas ${getIconeMensagem(tipo)}"></i>
                <span>${texto}</span>
            </div>
            <button class="message-close" onclick="this.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        document.body.appendChild(msg);
        setTimeout(() => msg.remove(), 5000);
    }

    function getIconeMensagem(tipo) {
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };
        return icons[tipo] || 'fa-info-circle';
    }

    function mostrarLoading(texto = 'Carregando...') {
        const loading = document.createElement('div');
        loading.className = 'global-loading';
        loading.innerHTML = `
            <div class="loading-content">
                <div class="loading-spinner"></div>
                <div class="loading-text">${texto}</div>
            </div>
        `;
        document.body.appendChild(loading);
    }

    function esconderLoading() {
        document.querySelectorAll('.global-loading').forEach(el => el.remove());
    }

    function abrirModal(titulo, conteudo, onConfirm = null) {
        const modal = document.getElementById('modal');
        const modalTitulo = document.getElementById('modal-title');
        const modalCorpo = document.getElementById('modal-body');
        const modalConfirmar = document.getElementById('modal-confirm');

        if (!modal || !modalTitulo || !modalCorpo) return;

        modalTitulo.textContent = titulo;
        modalCorpo.innerHTML = conteudo;
        modal.classList.add('active');

        if (onConfirm && modalConfirmar) {
            modalConfirmar.onclick = () => {
                onConfirm();
                fecharModal();
            };
            modalConfirmar.style.display = 'block';
        } else if (modalConfirmar) {
            modalConfirmar.style.display = 'none';
        }
    }

    function fecharModal() {
        const modal = document.getElementById('modal');
        if (modal) modal.classList.remove('active');
    }

    function getFormEditarPerfil() {
        if (!Estado.usuario) return '<p>Usuário não encontrado</p>';
        
        return `
            <form id="form-editar-perfil">
                <div class="form-group">
                    <label>Nome Completo</label>
                    <input type="text" class="form-control" value="${Estado.usuario.nome}">
                </div>
                <div class="form-group">
                    <label>E-mail</label>
                    <input type="email" class="form-control" value="${Estado.usuario.email}">
                </div>
                <div class="form-group">
                    <label>Telefone</label>
                    <input type="tel" class="form-control" value="${Estado.usuario.telefone || ''}">
                </div>
            </form>
        `;
    }

    function getFormAlterarSenha() {
        return `
            <form id="form-alterar-senha">
                <div class="form-group">
                    <label>Senha Atual</label>
                    <input type="password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Nova Senha</label>
                    <input type="password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Confirmar Nova Senha</label>
                    <input type="password" class="form-control" required>
                </div>
            </form>
        `;
    }

    function configurarEventos() {
        document.getElementById('login-btn')?.addEventListener('click', () => {
            const perfil = document.getElementById('login-type').value;
            const email = document.getElementById('username').value;
            const senha = document.getElementById('password').value;
            fazerLogin(email, senha, perfil);
        });

        document.getElementById('password')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const perfil = document.getElementById('login-type').value;
                const email = document.getElementById('username').value;
                const senha = document.getElementById('password').value;
                fazerLogin(email, senha, perfil);
            }
        });

        document.getElementById('logout-btn')?.addEventListener('click', fazerLogout);
        document.getElementById('menu-toggle')?.addEventListener('click', toggleSidebar);
    }

    function configurarModal() {
        const modal = document.getElementById('modal');
        const fechar = document.getElementById('modal-close');
        const cancelar = document.getElementById('modal-cancel');

        modal?.addEventListener('click', (e) => {
            if (e.target === modal) fecharModal();
        });

        fechar?.addEventListener('click', fecharModal);
        cancelar?.addEventListener('click', fecharModal);
    }

    function carregarEstilos() {
        // Estilos são carregados via CSS externo
    }

    window.SISTEMA = {
        fazerLogin,
        fazerLogout,
        navegarPara,
        toggleSidebar,
        abrirModal,
        fecharModal,
        mostrarMensagem,
        getEstado: () => ({ ...Estado })
    };

    window.navegarPara = navegarPara;
    window.abrirModal = abrirModal;
    window.mostrarMensagem = mostrarMensagem;

    console.log('✅ Sistema v8.1 carregado com sucesso!');
}